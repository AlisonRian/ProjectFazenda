package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import application.FazendaEventos;
import dominio.FazendaEvento;
import dominio.FazendaEventosDTO;
import dominio.Caprino;
import dominio.Evento;
import dominio.Fazenda;

public class FazendaEventosDAO {
	private Conexao c;
	private final String RELATORIO = "SELECT Fazenda.id AS \"id_fazenda\",Eventos.id AS \"id_evento\",Fazenda.nome AS fazenda_nome,Eventos.nome AS evento_nome, \r\n"
			+ "			  Eventos.local,Fazenda.qtd_animais , Eventos.data\r\n"
			+ "			 FROM FazendaEventos\r\n"
			+ "			 JOIN Fazenda ON FazendaEventos.id_fazenda = fazenda.id\r\n"
			+ "			 JOIN Eventos ON FazendaEventos.id_evento = eventos.id;";
	private final String BUSCAREVENTOS =  "SELECT Fazenda.id AS \"id_fazenda\",Eventos.id AS \"id_evento\",Fazenda.nome AS fazenda_nome,Eventos.nome AS evento_nome, \r\n"
			+ "			  Eventos.local,Fazenda.qtd_animais , Eventos.data\r\n"
			+ "			 FROM FazendaEventos\r\n"
			+ "			 JOIN Fazenda ON FazendaEventos.id_fazenda = fazenda.id\r\n"
			+ "			 JOIN Eventos ON FazendaEventos.id_evento = eventos.id\r\n"
			+ "			 where id_evento=?;";
	private final String BUSCARFAZENDA = "SELECT Fazenda.id AS \"id_fazenda\",Eventos.id AS \"id_evento\",Fazenda.nome AS fazenda_nome,Eventos.nome AS evento_nome, \r\n"
			+ "			  Eventos.local,Fazenda.qtd_animais , Eventos.data\r\n"
			+ "			 FROM FazendaEventos\r\n"
			+ "			 JOIN Fazenda ON FazendaEventos.id_fazenda = fazenda.id\r\n"
			+ "			 JOIN Eventos ON FazendaEventos.id_evento = eventos.id\r\n"
			+ "			 where id_fazenda=?;";
	private final String BUSCARCOMBINADA = "SELECT Fazenda.id AS \"id_fazenda\",Eventos.id AS \"id_evento\",Fazenda.nome AS fazenda_nome,Eventos.nome AS evento_nome, \r\n"
			+ "			  Eventos.local,Fazenda.qtd_animais , Eventos.data\r\n"
			+ "			 FROM FazendaEventos\r\n"
			+ "			 JOIN Fazenda ON FazendaEventos.id_fazenda = fazenda.id\r\n"
			+ "			 JOIN Eventos ON FazendaEventos.id_evento = eventos.id\r\n"
			+ "			 where id_evento = ? AND id_fazenda = ?";
	private final String ALTERAR = "update FazendaEventos set id_fazenda, id_evento where id_fazenda = ?";
	private final String EXCLUIR = "delete from FazendaEventos where id_fazenda=?";
	private final String EXCLUIREVENTOS = "delete from FazendaEventos where id_evento=?";
	private final String EXCLUIRCOMBINADO = "delete from FazendaEventos where id_fazenda=? and id_evento = ?";
	private final String INSERIR = "insert into FazendaEventos (id_fazenda, id_evento) values (?,?)";
	
	public FazendaEventosDAO() {
		c = new Conexao("jdbc:postgresql://localhost:5432/FazendaTeste",
                "postgres","pgadmin");
	}
	
	public ArrayList<FazendaEventosDTO> relatorio() {
	    ArrayList<FazendaEventosDTO> lista = new ArrayList<>();
	    try {
	        c.conectar();
	        Statement instrucao = c.getConexao().createStatement();
	        ResultSet rs = instrucao.executeQuery(RELATORIO);
	        while (rs.next()) {
	            FazendaEventosDTO dto = new FazendaEventosDTO(
	                    rs.getInt("id_fazenda"),
	                    rs.getInt("id_evento"),
	                    rs.getString("fazenda_nome"),
	                    rs.getString("evento_nome"),
	                    rs.getString("local"),
	                    rs.getInt("qtd_animais"),
	                    rs.getString("data")
	            );
	            lista.add(dto);
	        }
	        c.desconectar();
	    } catch (Exception e) {
	        System.out.println("Erro: " + e);
	    }
	    return lista;
	}

	
	public ArrayList<FazendaEventosDTO> buscarIdEvento(int id) {
		ArrayList<FazendaEventosDTO> lista = new ArrayList<>();
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCAREVENTOS);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
            while(rs.next()){
            	FazendaEventosDTO f = new FazendaEventosDTO(
	                    rs.getInt("id_fazenda"),
	                    rs.getInt("id_evento"),
	                    rs.getString("fazenda_nome"),
	                    rs.getString("evento_nome"),
	                    rs.getString("local"),
	                    rs.getInt("qtd_animais"),
	                    rs.getString("data")
	            );
                lista.add(f);
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public ArrayList<FazendaEventosDTO> buscarIdFazenda(int id) {
		ArrayList<FazendaEventosDTO> lista = new ArrayList();
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCARFAZENDA);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
			while(rs.next()) {
				FazendaEventosDTO f = new FazendaEventosDTO(
	                    rs.getInt("id_fazenda"),
	                    rs.getInt("id_evento"),
	                    rs.getString("fazenda_nome"),
	                    rs.getString("evento_nome"),
	                    rs.getString("local"),
	                    rs.getInt("qtd_animais"),
	                    rs.getString("data")
	            );
                lista.add(f);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public FazendaEventosDTO buscarCombinada(int id_fazenda, int id_evento) {
		FazendaEventosDTO f = null;
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCARCOMBINADA);
			instrucao.setInt(1, id_evento);
			instrucao.setInt(2, id_fazenda);
            ResultSet rs = instrucao.executeQuery();
            if(rs.next()){
                f = new FazendaEventosDTO(
	                    rs.getInt("id_fazenda"),
	                    rs.getInt("id_evento"),
	                    rs.getString("fazenda_nome"),
	                    rs.getString("evento_nome"),
	                    rs.getString("local"),
	                    rs.getInt("qtd_animais"),
	                    rs.getString("data")
	            );
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return f;
	}
	
	public void alterar(int id_fazenda, int id_evento, int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(ALTERAR);
			instrucao.setInt(1,id_fazenda);
			instrucao.setInt(2, id_evento);
			instrucao.setInt(3, id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	
	public void inserir(int id_fazenda,int id_evento) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(INSERIR);
			instrucao.setInt(1,id_fazenda);
			instrucao.setInt(2,id_evento);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluirIdFazenda(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIR);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluirIdEventos(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIREVENTOS);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluirCombinado(int id_fazenda, int id_evento) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIRCOMBINADO);
			instrucao.setInt(1,id_fazenda);
			instrucao.setInt(2,id_evento);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
}
