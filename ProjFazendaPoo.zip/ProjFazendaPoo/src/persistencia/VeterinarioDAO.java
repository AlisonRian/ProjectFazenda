package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dominio.Caprino;
import dominio.Veterinario;




public class VeterinarioDAO {
	private Conexao c;
	private final String RELATORIO = "select * from Veterinario";
	private final String BUSCAR =  "select * from Veterinario where id = ?";
	private final String BUSCARFAZENDA = "select * from Veterinario where id_fazenda = ?";
	private final String ALTERAR = "update Veterinario set nome =  ?, contato = ? where id = ?";
	private final String EXCLUIR = "delete from Veterinario where id=?";
	private final String EXCLUIRFAZENDA = "delete from Veterinario where id_fazenda = ?";
	private final String INSERIR = "insert into Veterinario (id,id_fazenda,nome,contato) values (?,?,?,?)";
	
	public VeterinarioDAO() {
		c = new Conexao("jdbc:postgresql://localhost:5432/FazendaTeste",
                "postgres","pgadmin");
	}
	
	public ArrayList<Veterinario> relatorio(){
		ArrayList<Veterinario> lista = new ArrayList();
		try {
			c.conectar();
			Statement instrucao = c.getConexao().createStatement();	
			ResultSet rs = instrucao.executeQuery(RELATORIO);
			while(rs.next()) {
				Veterinario v = new Veterinario(rs.getString("nome"),rs.getString("contato"),rs.getInt("id"), rs.getInt("id_fazenda"));
				lista.add(v);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public Veterinario buscar(int id) {
		Veterinario v = null;
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCAR);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
            if(rs.next()){
                v = new Veterinario(rs.getString("nome"),rs.getString("contato"),rs.getInt("id"), rs.getInt("id_fazenda"));
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return v;
	}
	
	public ArrayList<Veterinario> buscarIdFazenda(int id) {
		ArrayList<Veterinario> lista = new ArrayList();
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCARFAZENDA);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
			while(rs.next()) {
				Veterinario v = new Veterinario(rs.getString("nome"),rs.getString("contato"),rs.getInt("id"), rs.getInt("id_fazenda"));
				lista.add(v);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public void alterar(String nome, String contato, int idAntigo) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(ALTERAR);
			instrucao.setString(1,nome);
			instrucao.setString(2, contato);
			instrucao.setInt(3, idAntigo);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	
	public void inserir(int id,int id_fazenda,String nome, String contato) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(INSERIR);
			instrucao.setInt(1,id);
			instrucao.setInt(2, id_fazenda);
			instrucao.setString(3,nome);
			instrucao.setString(4, contato);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluir(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIR);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	public void excluirIdFazenda(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIRFAZENDA);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
}

