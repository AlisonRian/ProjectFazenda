package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dominio.Evento;





public class EventoDAO {
	private Conexao c;
	private final String RELATORIO = "select * from Eventos";
	private final String BUSCAR =  "select * from Eventos where id = ?";
	private final String ALTERAR = "update Eventos set nome =  ?,data = ?, local = ? where id = ?";
	private final String EXCLUIR = "delete from Eventos where id=?";
	private final String INSERIR = "insert into Eventos (id,nome,data,local) values (?,?,?,?)";
	
	public EventoDAO() {
		c = new Conexao("jdbc:postgresql://localhost:5432/FazendaTeste",
                "postgres","pgadmin");
	}
	
	public ArrayList<Evento> relatorio(){
		ArrayList<Evento> lista = new ArrayList();
		try {
			c.conectar();
			Statement instrucao = c.getConexao().createStatement();	
			ResultSet rs = instrucao.executeQuery(RELATORIO);
			while(rs.next()) {
				Evento ev = new Evento(rs.getString("nome"),rs.getString("local"),rs.getString("data"), rs.getInt("id"));
				lista.add(ev);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public Evento buscar(int id) {
		Evento ev = null;
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCAR);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
            if(rs.next()){
                ev = new Evento(rs.getString("nome"),rs.getString("local"),rs.getString("data"), rs.getInt("id"));
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return ev;
	}
	
	public void alterar(String nome, String data, String local, int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(ALTERAR);
			instrucao.setString(1,nome);
			instrucao.setString(2, data);
			instrucao.setString(3, local);
			instrucao.setInt(4, id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	
	public void inserir(int id,String nome,String data,String local) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(INSERIR);
			instrucao.setInt(1,id);
			instrucao.setString(2,nome);
			instrucao.setString(3, data);
			instrucao.setString(4, local);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluir(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIR);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
}


