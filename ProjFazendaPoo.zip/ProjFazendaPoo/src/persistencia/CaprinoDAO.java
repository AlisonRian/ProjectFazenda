package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dominio.Caprino;

public class CaprinoDAO {
	private Conexao c;
	private final String RELATORIO = "select * from Caprinos";
	private final String BUSCAR =  "select * from Caprinos where id = ?";
	private final String BUSCARFAZENDA = "select * from Caprinos where id_fazenda = ?";
	private final String ALTERAR = "update Caprinos set nome =  ?, raca = ?, idade = ? where id = ?";
	private final String EXCLUIR = "delete from Caprinos where id=?";
	private final String EXCLUIRFAZENDA = "delete from Caprinos where id_fazenda=?";
	private final String INSERIR = "insert into Caprinos (id, nome, raca, idade, id_fazenda) values (?,?,?,?,?)";
	
	public CaprinoDAO() {
		c = new Conexao("jdbc:postgresql://localhost:5432/FazendaTeste",
                "postgres","pgadmin");
	}
	
	public ArrayList<Caprino> relatorio(){
		ArrayList<Caprino> lista = new ArrayList();
		try {
			c.conectar();
			Statement instrucao = c.getConexao().createStatement();	
			ResultSet rs = instrucao.executeQuery(RELATORIO);
			while(rs.next()) {
				Caprino c = new Caprino(rs.getInt("idade"),rs.getInt("id"), rs.getInt("id_fazenda"),rs.getString("nome"), rs.getString("raca"));
				lista.add(c);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public Caprino buscar(int id) {
		Caprino caprino = null;
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCAR);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
            if(rs.next()){
                caprino = new Caprino(rs.getInt("idade"),rs.getInt("id"),rs.getInt("id_fazenda"), rs.getString("nome"),rs.getString("raca"));
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return caprino;
	}
	
	public ArrayList<Caprino> buscarIdFazenda(int id) {
		ArrayList<Caprino> lista = new ArrayList();
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCARFAZENDA);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
			while(rs.next()) {
				Caprino c = new Caprino(rs.getInt("idade"),rs.getInt("id"), rs.getInt("id_fazenda"),rs.getString("nome"), rs.getString("raca"));
				lista.add(c);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public void alterar(String nome,String raca,int idade,int idAntigo) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(ALTERAR);
			instrucao.setString(1,nome);
			instrucao.setString(2, raca);
			instrucao.setInt(3, idade);
			instrucao.setInt(4, idAntigo);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	
	public void inserir(int id,String nome,String raca,int idade,int id_fazenda) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(INSERIR);
			instrucao.setInt(1,id);
			instrucao.setString(2, nome);
			instrucao.setString(3, raca);
			instrucao.setInt(4,idade);
			instrucao.setInt(5,id_fazenda);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluir(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIR);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	public void excluirIdFazenda(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIRFAZENDA);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
}
