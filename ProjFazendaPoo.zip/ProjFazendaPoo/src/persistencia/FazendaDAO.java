package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dominio.Fazenda;
import dominio.Veterinario;



public class FazendaDAO {
	private Conexao c;
	private final String RELATORIO = "select * from Fazenda";
	private final String BUSCAR =  "select * from Fazenda where id = ?";
	private final String BUSCARFAZENDA = "select * from Fornecedor where id_fazenda = ?";
	private final String ALTERAR = "update Fazenda set nome =  ?, qtd_animais = ? where id = ?";
	private final String EXCLUIR = "delete from Fazenda where id=?";
	private final String EXCLUIRFAZENDA = "delete from Veterinario where id_fazenda = ?";
	private final String INSERIR = "insert into Fazenda (id, nome, qtd_animais) values (?,?,?)";
	
	public FazendaDAO() {
		c = new Conexao("jdbc:postgresql://localhost:5432/FazendaTeste",
                "postgres","pgadmin");
	}
	
	public ArrayList<Fazenda> relatorio(){
		ArrayList<Fazenda> lista = new ArrayList();
		try {
			c.conectar();
			Statement instrucao = c.getConexao().createStatement();	
			ResultSet rs = instrucao.executeQuery(RELATORIO);
			while(rs.next()) {
				Fazenda f = new Fazenda(rs.getString("nome"),rs.getInt("id"), rs.getInt("qtd_animais"));
				lista.add(f);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public Fazenda buscar(int id) {
		Fazenda f = null;
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCAR);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
            if(rs.next()){
                f = new Fazenda(rs.getString("nome"),rs.getInt("id"),rs.getInt("qtd_animais"));
            }
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return f;
	}
	
	public ArrayList<Veterinario> buscarFazenda(int id) {
		ArrayList<Veterinario> lista = new ArrayList();
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(BUSCARFAZENDA);
			instrucao.setInt(1, id);
            ResultSet rs = instrucao.executeQuery();
			while(rs.next()) {
				Veterinario v = new Veterinario(rs.getString("nome"),rs.getString("contato"),rs.getInt("id"), rs.getInt("id_fazenda"));
				lista.add(v);
			}
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
		return lista;
	}
	
	public void alterar(String nome,int qtd_animais,int idAntigo) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(ALTERAR);
			instrucao.setString(1,nome);
			instrucao.setInt(2, qtd_animais);
			instrucao.setInt(3, idAntigo);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	
	public void inserir(int id,String nome,int qtd_animais) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(INSERIR);
			instrucao.setInt(1,id);
			instrucao.setString(2, nome);
			instrucao.setInt(3, qtd_animais);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	
	public void excluir(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIR);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
	public void excluirIdFazenda(int id) {
		try {
			c.conectar();
			PreparedStatement instrucao = c.getConexao().prepareStatement(EXCLUIRFAZENDA);
			instrucao.setInt(1,id);
			instrucao.execute();
			c.desconectar();
		}catch(Exception e) {
			System.out.println("Erro: "+e);
		}
	}
}
