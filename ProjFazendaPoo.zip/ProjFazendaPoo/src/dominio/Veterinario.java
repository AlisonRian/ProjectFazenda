package dominio;

public class Veterinario {
	private String nome, contato;
	private int id, id_fazenda;
	
	public Veterinario() {
		
	}
	public Veterinario(String nome, String contato, int id, int id_fazenda) {
		this.nome = nome;
		this.contato = contato;
		this.id = id;
		this.id_fazenda = id_fazenda;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setIdFazenda(int id_fazenda) {
		this.id_fazenda = id_fazenda;
	}
	public String getNome() {
		return nome;
	}
	public String getContato() {
		return contato;
	}
	public int getId() {
		return id;
	}
	public int getIdFazenda() {
		return id_fazenda;
	}
}
