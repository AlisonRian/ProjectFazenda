package dominio;

public class Evento {
	private String nome , local, data;
	private int id;
	
	public Evento() {
		
	}
	public Evento(String nome, String local, String data, int id) {
		this.nome = nome;
		this.local = local;
		this.data = data;
		this.id = id;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public void setData(String data) {
		this.data = data;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public String getLocal() {
		return local;
	}
	public String getData() {
		return data;
	}
	public int getId() {
		return id;
	}
}

