package dominio;

public class FazendaEventosDTO {
	    private int id_fazenda;
	    private int id_evento;
	    private String nomeFazenda;
	    private String nomeEvento;
	    private String localEvento;
	    private int qtdAnimaisFazenda;
	    private String dataEvento;

	    public FazendaEventosDTO(int idFazenda, int idEvento, String nomeFazenda, String nomeEvento, String localEvento, int qtdAnimaisFazenda, String dataEvento) {
	        this.id_fazenda = idFazenda;
	        this.id_evento = idEvento;
	        this.nomeFazenda = nomeFazenda;
	        this.nomeEvento = nomeEvento;
	        this.localEvento = localEvento;
	        this.qtdAnimaisFazenda = qtdAnimaisFazenda;
	        this.dataEvento = dataEvento;
	    }
	    public void setIdFazenda(int id) {
	    	id_fazenda = id; 
	    }
	    
	    public void setIdEvento(int id) {
	    	id_evento = id; 
	    }
	    public void setNomeFazenda(String nome) {
	    	nomeFazenda = nome; 
	    }
	    public void setNomeEvento(String nome) {
	    	nomeEvento = nome; 
	    }
	    public void setLocalEvento(String nome) {
	    	localEvento = nome; 
	    }
	    public void setQtdAnimaisFazenda(int qtd) {
	    	qtdAnimaisFazenda = qtd;
	    }
	    public void setDataEvento(String data) {
	    	dataEvento = data;
	    }
	    
	    public int getIdFazenda() {
	    	return id_fazenda;
	    }
	    public int getIdEvento() {
	    	return id_evento;
	    }
	   public String getNomeFazenda() {
		   return nomeFazenda;
	   }
	   public String getNomeEvento() {
		   return nomeEvento;
	   }
	   public String getLocalEvento() {
		   return localEvento;
	   }
	   public int getQtdAnimaisFazenda() {
		   return qtdAnimaisFazenda;
	   }
	   public String getDataEvento() {
		   return dataEvento;
	   }
}

