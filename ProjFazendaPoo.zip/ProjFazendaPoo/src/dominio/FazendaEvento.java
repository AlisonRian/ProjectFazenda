package dominio;

public class FazendaEvento {
	private int id_fazenda, id_evento;
	 private Fazenda fazenda;
	 private Evento evento;
	
	public FazendaEvento() {
		
	}
	public FazendaEvento(int id_fazenda, int id_evento) {
		this.id_fazenda = id_fazenda;
		this.id_evento = id_evento;
	}
	
	public void setIdFazenda(int id_fazenda) {
		this.id_fazenda = id_fazenda;
	}
	public void setIdEvento(int id_evento) {
		this.id_evento = id_evento;
	}
	
	public int getIdFazenda() {
		return id_fazenda;
	}
	public int getIdEvento() {
		return id_evento;
	}
	public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }
}
