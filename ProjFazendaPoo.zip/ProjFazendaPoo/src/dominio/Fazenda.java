package dominio;

public class Fazenda {
	private String nome;
	private int id, qtdAnimais;
	
	public Fazenda() {
		
	}
	public Fazenda(String nome,int id, int qtdAnimais) {
		this.nome = nome;
		this.id = id;
		this.qtdAnimais = qtdAnimais;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setQtd(int qtdAnimais) {
		this.qtdAnimais = qtdAnimais;
	}
	public String getNome() {
		return nome;
	}
	public int getId() {
		return id;
	}
	public int getQtd() {
		return qtdAnimais;
	}
	
}
