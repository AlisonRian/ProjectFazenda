package dominio;

public class Caprino {
	private int idade, id_fazenda, id;
	private String raca, nome;
	
	public Caprino() {
		
	}
	public Caprino(int idade, int id, int id_fazenda, String nome, String raca) {
		this.idade = idade;
		this.id = id;
		this.id_fazenda = id_fazenda;
		this.nome = nome;
		this.raca = raca;
	}
	
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setIdFazenda(int id_fazenda) {
		this.id_fazenda = id_fazenda;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	public int getIdade() {
		return idade;
	}
	public int getId() {
		return id;
	}
	public int getIdFazenda() {
		return id_fazenda;
	}
	public String getNome() {
		return nome;
	}
	public String getRaca() {
		return raca;
	}
}	
