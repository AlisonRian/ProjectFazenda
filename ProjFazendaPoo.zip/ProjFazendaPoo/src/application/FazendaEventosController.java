package application;

import java.util.Optional;

import dominio.Evento;
import dominio.FazendaEvento;
import dominio.FazendaEventosDTO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import persistencia.EventoDAO;
import persistencia.FazendaEventosDAO;

public class FazendaEventosController {
	@FXML
    private Button btnBuscar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnRelatorio;

    @FXML
    private Button btnRelátorio;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnVoltar;

    @FXML
    private TextField buscarID;

    @FXML
    private TextField editarNome;

    @FXML
    private TextField editarQtd;

    @FXML
    private TextField inserirIDEventos;

    @FXML
    private TextField inserirIDFazenda;
    
    @FXML
    private TextField buscarEventos;

    @FXML
    private Label lblEditarNome;

    @FXML
    private Label lblEditarQtd;

    @FXML
    private Pane pnEditar;
    
    @FXML
    private TableColumn<FazendaEventos, String> tbcBuscarData;

    @FXML
    private TableColumn<FazendaEventos, String> tbcData;

    @FXML
    private TableColumn<FazendaEventos, String> tbcBuscarEventos;

    @FXML
    private TableColumn<FazendaEventos, String> tbcEventos;

    @FXML
    private TableColumn<FazendaEventos, String> tbcBuscarFazenda;

    @FXML
    private TableColumn<FazendaEventos, String> tbcFazenda;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcBuscarID;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcID;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcBuscarIDEventos;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcIDEventos;

    @FXML
    private TableColumn<FazendaEventos, String> tbcBuscarLocal;

    @FXML
    private TableColumn<FazendaEventos, String> tbcLocal;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcBuscarQtd;

    @FXML
    private TableColumn<FazendaEventos, Integer> tbcQtd;

    @FXML
    private TableView<FazendaEventosDTO> tbvBuscar;

    @FXML
    private TableView<FazendaEventosDTO> tbvRelatorio;

    @FXML
    private AnchorPane telaFazenda;
    private boolean rel = false;
    FazendaEvento fe;
    FazendaEventosDAO feDAO = new FazendaEventosDAO();
    private ObservableList<FazendaEventosDTO> fazendaeventos = FXCollections.observableArrayList();
    private ObservableList<FazendaEventosDTO> buscas = FXCollections.observableArrayList();
    Optional<ButtonType> opc;
    Alert alert = new Alert(AlertType.INFORMATION);
    Alert alertC = new Alert(AlertType.CONFIRMATION);

    @FXML
    void onClickBtnBuscar(ActionEvent event) {
    	if(!buscarID.getText().isEmpty() && buscarEventos.getText().isEmpty()) {
       		buscas.clear();
       		tbcBuscarID.setCellValueFactory(new PropertyValueFactory<>("IdFazenda"));
       		tbcBuscarIDEventos.setCellValueFactory(new PropertyValueFactory<>("IdEvento"));
       		tbcBuscarFazenda.setCellValueFactory(new PropertyValueFactory<>("nomeFazenda"));
       		tbcBuscarEventos.setCellValueFactory(new PropertyValueFactory<>("nomeEvento"));
       		tbcBuscarLocal.setCellValueFactory(new PropertyValueFactory<>("localEvento"));
       		tbcBuscarQtd.setCellValueFactory(new PropertyValueFactory<>("QtdAnimaisFazenda"));
       		tbcBuscarData.setCellValueFactory(new PropertyValueFactory<>("dataEvento"));
            buscas.addAll(feDAO.buscarIdFazenda(Integer.parseInt(buscarID.getText())));
            tbvBuscar.setItems(buscas);  
    	}else if(!buscarEventos.getText().isEmpty() && buscarID.getText().isEmpty()) {
       		buscas.clear();
       		tbcBuscarID.setCellValueFactory(new PropertyValueFactory<>("IdFazenda"));
       		tbcBuscarIDEventos.setCellValueFactory(new PropertyValueFactory<>("IdEvento"));
       		tbcBuscarFazenda.setCellValueFactory(new PropertyValueFactory<>("nomeFazenda"));
       		tbcBuscarEventos.setCellValueFactory(new PropertyValueFactory<>("nomeEvento"));
       		tbcBuscarLocal.setCellValueFactory(new PropertyValueFactory<>("localEvento"));
       		tbcBuscarQtd.setCellValueFactory(new PropertyValueFactory<>("QtdAnimaisFazenda"));
       		tbcBuscarData.setCellValueFactory(new PropertyValueFactory<>("dataEvento"));
        	buscas.addAll(feDAO.buscarIdEvento(Integer.parseInt(buscarEventos.getText())));
        	tbvBuscar.setItems(buscas);
    	} else if(!buscarEventos.getText().isEmpty() && !buscarID.getText().isEmpty()) {
       		buscas.clear();
       		tbcBuscarID.setCellValueFactory(new PropertyValueFactory<>("IdFazenda"));
       		tbcBuscarIDEventos.setCellValueFactory(new PropertyValueFactory<>("IdEvento"));
       		tbcBuscarFazenda.setCellValueFactory(new PropertyValueFactory<>("nomeFazenda"));
       		tbcBuscarEventos.setCellValueFactory(new PropertyValueFactory<>("nomeEvento"));
       		tbcBuscarLocal.setCellValueFactory(new PropertyValueFactory<>("localEvento"));
       		tbcBuscarQtd.setCellValueFactory(new PropertyValueFactory<>("QtdAnimaisFazenda"));
       		tbcBuscarData.setCellValueFactory(new PropertyValueFactory<>("dataEvento"));
        	buscas.add(feDAO.buscarCombinada(Integer.parseInt(buscarID.getText()),(Integer.parseInt(buscarEventos.getText()))));
        	tbvBuscar.setItems(buscas);
    	}

    }

    @FXML
    void onClickBtnConfirmar(ActionEvent event) {

    }

    @FXML
    void onClickBtnEditar(ActionEvent event) {

    }

    @FXML
    void onClickBtnInserir(ActionEvent event) {
    	fe = new FazendaEvento();
    	fe.setIdFazenda(Integer.parseInt(inserirIDFazenda.getText()));
    	fe.setIdEvento(Integer.parseInt(inserirIDEventos.getText()));
    	feDAO.inserir(fe.getIdFazenda(),fe.getIdEvento());
    	
    	 fazendaeventos.clear(); //Limpar a  ObservableList
    	 fazendaeventos.addAll(feDAO.relatorio()); // Inserir os novos dados
    	 tbvRelatorio.refresh();// Atualizar a TableView
    	 alert.setTitle("");
    	 alert.setHeaderText("");
    	 alert.setContentText("Dados inseridos com sucesso!");
    	 alert.show();
    	 inserirIDFazenda.setText("");
    	 inserirIDEventos.setText("");
    }

    @FXML
    void onClickBtnRelatorio(ActionEvent event) {
   	 if(rel==false) {
   		fazendaeventos.clear();
   		tbcID.setCellValueFactory(new PropertyValueFactory<>("IdFazenda"));
   		tbcIDEventos.setCellValueFactory(new PropertyValueFactory<>("IdEvento"));
   		tbcFazenda.setCellValueFactory(new PropertyValueFactory<>("nomeFazenda"));
   		tbcEventos.setCellValueFactory(new PropertyValueFactory<>("nomeEvento"));
   		tbcLocal.setCellValueFactory(new PropertyValueFactory<>("localEvento"));
   		tbcQtd.setCellValueFactory(new PropertyValueFactory<>("QtdAnimaisFazenda"));
   		tbcData.setCellValueFactory(new PropertyValueFactory<>("dataEvento"));
        fazendaeventos.addAll(feDAO.relatorio());
        tbvRelatorio.setItems(fazendaeventos);
	 }
	 rel=true;
    }

    @FXML
    void onClickBtnRemover(ActionEvent event) {
    	if(!buscarID.getText().isEmpty() && buscarEventos.getText().isEmpty()){
    		alertC.setTitle("");
        	alertC.setHeaderText("");
        	alertC.setContentText("Atenção a exclusão, removerá todas as relações dessa fazenda");
        	opc = alertC.showAndWait();
        	if(opc.get() == ButtonType.OK) {
            		feDAO.excluirIdFazenda(Integer.parseInt(buscarID.getText()));
            		buscas.clear();
            		fazendaeventos.clear(); 
               	 	fazendaeventos.addAll(feDAO.relatorio()); 
               	 	tbvRelatorio.refresh();
        	       	alert.setTitle("");
        	 		alert.setHeaderText("");
            		alert.setContentText("Relação excluída com sucesso!");
            		alert.show();
        		}else {
            		alert.setTitle("");
            		alert.setHeaderText("");
            		alert.setContentText("Exclusão cancelada!");
            		alert.show();
            	}
	    	} else if (!buscarEventos.getText().isEmpty() && buscarID.getText().isEmpty()){
	         	alertC.setTitle("");
	        	alertC.setHeaderText("");
	        	alertC.setContentText("Atenção a exclusão, removerá todas as relações desse evento!");
	        	opc = alertC.showAndWait();
	        	if(opc.get()==ButtonType.OK) {
				feDAO.excluirIdEventos(Integer.parseInt(buscarEventos.getText()));
	    		buscas.clear();
	    		fazendaeventos.clear(); //Limpar a  ObservableList
	       	 	fazendaeventos.addAll(feDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Exclusão concluida!");
	    		alert.show();
	        	}else {
	        		alert.setTitle("");
	        		alert.setHeaderText("");
	        		alert.setContentText("Exclusão cancelada!");
	        		alert.show();
	        	}
	    	} else {
	    		alertC.setTitle("");
	        	alertC.setHeaderText("");
	        	alertC.setContentText("Atenção a exclusão, removerá a relação entre fazenda e evento");
	        	opc = alertC.showAndWait();
	        	if(opc.get()==ButtonType.OK) {
				feDAO.excluirCombinado(Integer.parseInt(buscarID.getText()), Integer.parseInt(buscarEventos.getText()));
	    		buscas.clear();
	    		fazendaeventos.clear(); //Limpar a  ObservableList
	       	 	fazendaeventos.addAll(feDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Exclusão concluida!");
	    		alert.show();
	        	}else {
	        		alert.setTitle("");
	        		alert.setHeaderText("");
	        		alert.setContentText("Exclusão cancelada!");
	        		alert.show();
	        	}
	    	}
    }

    @FXML
    void onClickBtnVoltar(ActionEvent event) {
    	Main.changeScreen(1);
    }
}
