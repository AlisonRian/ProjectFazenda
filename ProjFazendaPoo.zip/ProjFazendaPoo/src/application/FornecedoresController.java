package application;

import java.util.Optional;

import dominio.Fornecedor;
import dominio.Veterinario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import persistencia.FornecedorDAO;
import persistencia.VeterinarioDAO;

public class FornecedoresController {

    @FXML
    private Button btnBuscar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnRelatorio;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnVoltar;

    @FXML
    private TextField buscarID;

    @FXML
    private TextField buscarIDFazenda;

    @FXML
    private TextField editarNome;

    @FXML
    private TextField editarContato;

    @FXML
    private TextField inserirContato;

    @FXML
    private TextField inserirID;

    @FXML
    private TextField inserirIDFazenda;

    @FXML
    private TextField inserirNome;

    @FXML
    private Pane pnEditar;

    @FXML
    private TableColumn<Fornecedor, String> tbcBscContato;

    @FXML
    private TableColumn<Fornecedor, Integer> tbcBscID;

    @FXML
    private TableColumn<Fornecedor, Integer> tbcBscIDFazenda;

    @FXML
    private TableColumn<Fornecedor, String> tbcBscNome;

    @FXML
    private TableColumn<Fornecedor, String> tbcContato;

    @FXML
    private TableColumn<Fornecedor, Integer> tbcID;

    @FXML
    private TableColumn<Fornecedor, Integer> tbcIdFazenda;

    @FXML
    private TableColumn<Fornecedor, String> tbcNome;

    @FXML
    private TableView<Fornecedor> tbvBuscar;

    @FXML
    private TableView<Fornecedor> tbvRelatorio;
    
    private boolean rel=false;
    Fornecedor f;
    FornecedorDAO fDAO = new FornecedorDAO();
    private ObservableList<Fornecedor> fornecedores = FXCollections.observableArrayList();
    private ObservableList<Fornecedor> buscas = FXCollections.observableArrayList();
    Optional<ButtonType> opc;
    Alert alert = new Alert(AlertType.INFORMATION);
    Alert alertC = new Alert(AlertType.CONFIRMATION);

    public void initialize() {
        pnEditar.setVisible(false);
    }   

    @FXML
    void onClickBtnBuscar(ActionEvent event) {
    	btnEditar.setDisable(false);
    	buscas.clear();
    	if(!buscarIDFazenda.getText().equals("")) {
    		btnEditar.setDisable(true);
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.addAll(fDAO.buscarIdFazenda(Integer.parseInt(buscarIDFazenda.getText())));
        	tbvBuscar.setItems(buscas);
    	} else if(!buscarID.getText().equals("")) {
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.add(fDAO.buscar(Integer.parseInt(buscarID.getText())));
        	tbvBuscar.setItems(buscas);
    	}

    }

    @FXML
    void onClickBtnConfirmar(ActionEvent event) {
    	alertC.setTitle("");
    	alertC.setHeaderText("Alteração do fornecedor de ID "+buscarID.getText());
    	alertC.setContentText("Tem certeza de que deseja editar esse registro?");
    	opc = alertC.showAndWait();
    	if(opc.get() == ButtonType.OK) {
    		f = fDAO.buscar(Integer.parseInt(buscarID.getText()));
    		fDAO.alterar(editarNome.getText(),editarContato.getText(),Integer.parseInt(buscarID.getText()));
    		buscas.clear();
    		fornecedores.clear(); //Limpar a  ObservableList
       	 	fornecedores.addAll(fDAO.relatorio()); // Inserir os novos dados
       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	alert.setTitle("");
	 		alert.setHeaderText("");
    		alert.setContentText("Alteração realizada com sucesso!");
    		alert.show();
    	} else {
    		alert.setTitle("");
    		alert.setHeaderText("");
    		alert.setContentText("Alteração cancelada!");
    		alert.show();
    	}
    	pnEditar.setVisible(false);
    }

    @FXML
    void onClickBtnEditar(ActionEvent event) {
    	pnEditar.setVisible(true);
    }

    @FXML
    void onClickBtnInserir(ActionEvent event) {
    	f = new Fornecedor();
    	f.setId(Integer.parseInt(inserirID.getText()));
    	f.setIdFazenda(Integer.parseInt(inserirIDFazenda.getText()));
    	f.setNome(inserirNome.getText());
    	f.setContato(inserirContato.getText());
    	fDAO.inserir(f.getId(),f.getIdFazenda(),f.getNome(),f.getContato());
    	
    	 fornecedores.clear(); //Limpar a  ObservableList
    	 fornecedores.addAll(fDAO.relatorio()); // Inserir os novos dados
    	 tbvRelatorio.refresh();// Atualizar a TableView
    	 alert.setTitle("");
    	 alert.setHeaderText("");
    	 alert.setContentText("Dados inseridos com sucesso!");
    	 alert.show();
    	 inserirID.setText("");
    	 inserirNome.setText("");
    	 inserirContato.setText("");
    	 inserirIDFazenda.setText("");
    }

    @FXML
    void onClickBtnRelatorio(ActionEvent event) {
    	if(rel==false) {
  		  	tbcID.setCellValueFactory(new PropertyValueFactory<>("id")); 
  		    tbcNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
  		    tbcContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
  		    tbcIdFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
  		    fornecedores.addAll(fDAO.relatorio());
  		    tbvRelatorio.setItems(fornecedores);
  		    rel=true;
    	}
    	fornecedores.clear(); 
   	 	fornecedores.addAll(fDAO.relatorio()); 
   	 	tbvRelatorio.refresh();
    }

    @FXML
    void onClickBtnRemover(ActionEvent event) {
    	if(!buscarIDFazenda.getText().equals("")){
    		alertC.setTitle("");
        	alertC.setHeaderText("");
        	alertC.setContentText("Atenção, excluir utilizando o ID da fazenda irá excluir todos relacionados a fazenda!");
        	opc = alertC.showAndWait();
        	if(opc.get() == ButtonType.OK) {
            		fDAO.excluirIdFazenda(Integer.parseInt(buscarIDFazenda.getText()));
            		buscas.clear();
            		fornecedores.clear(); //Limpar a  ObservableList
            		fornecedores.addAll(fDAO.relatorio()); // Inserir os novos dados
               	 	tbvRelatorio.refresh();// Atualizar a TableView
        	       	alert.setTitle("");
        	 		alert.setHeaderText("");
            		alert.setContentText("Fornecedores excluidos com sucesso!");
            		alert.show();
        		}else {
            		alert.setTitle("");
            		alert.setHeaderText("");
            		alert.setContentText("Exclusão cancelada!");
            		alert.show();
            	}
	    	} else {
	         	alertC.setTitle("");
	        	alertC.setHeaderText("");
	        	alertC.setContentText("Atenção, tem certeza que deseja remover esse Fornecedor");
	        	opc = alertC.showAndWait();
	        	if(opc.get()==ButtonType.OK) {
				fDAO.excluir(Integer.parseInt(buscarID.getText()));
	    		buscas.clear();
	    		fornecedores.clear(); //Limpar a  ObservableList
	    		fornecedores.addAll(fDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Fornecedor excluido com sucesso!");
	    		alert.show();
	        	}else {
	        		alert.setTitle("");
	        		alert.setHeaderText("");
	        		alert.setContentText("Exclusão cancelada!");
	        		alert.show();
	        	}
	    	} 
    }

    @FXML
    void onClickBtnVoltar(ActionEvent event) {
    	Main.changeScreen(1);
    }	

}


