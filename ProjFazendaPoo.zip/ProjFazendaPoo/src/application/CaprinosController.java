package application;

import java.util.Optional;

import dominio.Caprino;
import dominio.Fazenda;
import persistencia.CaprinoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;



public class CaprinosController {

    @FXML
    private Button btnBuscar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnRelatorio;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnVoltar;

    @FXML
    private TextField buscarID;

    @FXML
    private TextField buscarIDFazenda;

    @FXML
    private TextField editarIdade;

    @FXML
    private TextField editarNome;

    @FXML
    private TextField editarRaca;

    @FXML
    private TextField inserirID;

    @FXML
    private TextField inserirIDFazenda;

    @FXML
    private TextField inserirIdade;

    @FXML
    private TextField inserirNome;

    @FXML
    private TextField inserirRaca;

    @FXML
    private Pane pnEditar;

    @FXML
    private TableColumn<Caprino, Integer> tbcBscID;

    @FXML
    private TableColumn<Caprino, Integer> tbcBscIDFazenda;

    @FXML
    private TableColumn<Caprino, Integer> tbcBscIdade;

    @FXML
    private TableColumn<Caprino, String> tbcBscNome;
    
    @FXML
    private TableColumn<Caprino, String> tbcBscRaca;

    @FXML
    private TableColumn<Caprino, Integer> tbcID;

    @FXML
    private TableColumn<Caprino, Integer> tbcIdFazenda;

    @FXML
    private TableColumn<Caprino, Integer> tbcIdade;

    @FXML
    private TableColumn<Caprino, Integer> tbcNome;

    @FXML
    private TableColumn<Caprino, String> tbcRaca;

    @FXML
    private TableView<Caprino> tbvBuscar;

    @FXML
    private TableView<Caprino> tbvRelatorio;
    
    private boolean rel=false;
    Caprino c;
    CaprinoDAO cDAO = new CaprinoDAO();
    private ObservableList<Caprino> caprinos = FXCollections.observableArrayList();
    private ObservableList<Caprino> buscas = FXCollections.observableArrayList();
    Optional<ButtonType> opc;
    Alert alert = new Alert(AlertType.INFORMATION);
    Alert alertC = new Alert(AlertType.CONFIRMATION);
    
    public void initialize() {
        pnEditar.setVisible(false);
    }   

    @FXML
    void onClickBtnBuscar(ActionEvent event) {
    	btnEditar.setDisable(false);
    	buscas.clear();
    	if(!buscarIDFazenda.getText().equals("")) {
    		btnEditar.setDisable(true);
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscRaca.setCellValueFactory(new PropertyValueFactory<>("raca"));
    	    tbcBscIdade.setCellValueFactory(new PropertyValueFactory<>("idade")); 
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.addAll(cDAO.buscarIdFazenda(Integer.parseInt(buscarIDFazenda.getText())));
        	tbvBuscar.setItems(buscas);
    	} else if(!buscarID.getText().equals("")) {
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscRaca.setCellValueFactory(new PropertyValueFactory<>("raca"));
    	    tbcBscIdade.setCellValueFactory(new PropertyValueFactory<>("idade")); 
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.add(cDAO.buscar(Integer.parseInt(buscarID.getText())));
        	tbvBuscar.setItems(buscas);
    	}

    }

    @FXML
    void onClickBtnConfirmar(ActionEvent event) {
    	alertC.setTitle("");
    	alertC.setHeaderText("Alteração do animal de ID "+buscarID.getText());
    	alertC.setContentText("Tem certeza de que deseja editar esse animal?");
    	opc = alertC.showAndWait();
    	if(opc.get() == ButtonType.OK) {
    		c = cDAO.buscar(Integer.parseInt(buscarID.getText()));
    		cDAO.alterar(editarNome.getText(),editarRaca.getText(),Integer.parseInt(editarIdade.getText()),Integer.parseInt(buscarID.getText()));
    		buscas.clear();
    		caprinos.clear(); //Limpar a  ObservableList
       	 	caprinos.addAll(cDAO.relatorio()); // Inserir os novos dados
       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	alert.setTitle("");
	 		alert.setHeaderText("");
    		alert.setContentText("Alteração realizada com sucesso!");
    		alert.show();
    	} else {
    		alert.setTitle("");
    		alert.setHeaderText("");
    		alert.setContentText("Alteração cancelada!");
    		alert.show();
    	}
    	pnEditar.setVisible(false);
    }

    @FXML
    void onClickBtnEditar(ActionEvent event) {
    	pnEditar.setVisible(true);
    }

    @FXML
    void onClickBtnInserir(ActionEvent event) {
    	c = new Caprino();
    	c.setId(Integer.parseInt(inserirID.getText()));
    	c.setIdFazenda(Integer.parseInt(inserirIDFazenda.getText()));
    	c.setNome(inserirNome.getText());
    	c.setRaca(inserirRaca.getText());
    	c.setIdade(Integer.parseInt(inserirIdade.getText()));
    	cDAO.inserir(c.getId(),c.getNome(),c.getRaca(),c.getIdade(),c.getIdFazenda());
    	
    	 caprinos.clear(); //Limpar a  ObservableList
    	 caprinos.addAll(cDAO.relatorio()); // Inserir os novos dados
    	 tbvRelatorio.refresh();// Atualizar a TableView
    	 alert.setTitle("");
    	 alert.setHeaderText("");
    	 alert.setContentText("Dados inseridos com sucesso!");
    	 alert.show();
    	 inserirID.setText("");
    	 inserirNome.setText("");
    	 inserirRaca.setText("");
    	 inserirIDFazenda.setText("");
    	 inserirIdade.setText("");
    }

    @FXML
    void onClickBtnRelatorio(ActionEvent event) {
    	if(rel==false) {
  		  	tbcID.setCellValueFactory(new PropertyValueFactory<>("id")); 
  		    tbcNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
  		    tbcRaca.setCellValueFactory(new PropertyValueFactory<>("raca")); 
  		    tbcIdade.setCellValueFactory(new PropertyValueFactory<>("idade")); 
  		    tbcIdFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
  		    caprinos.addAll(cDAO.relatorio());
  		    tbvRelatorio.setItems(caprinos);
  		    rel=true;
    	}
    	caprinos.clear(); 
   	 	caprinos.addAll(cDAO.relatorio()); 
   	 	tbvRelatorio.refresh();
    }

    @FXML
    void onClickBtnRemover(ActionEvent event) {
    	if(!buscarIDFazenda.getText().equals("")){
    		alertC.setTitle("");
        	alertC.setHeaderText("");
        	alertC.setContentText("Atenção, excluir utilizando o ID da fazenda irá remover todos os animais dessa fazenda!");
        	opc = alertC.showAndWait();
        	if(opc.get() == ButtonType.OK) {
            		cDAO.excluirIdFazenda(Integer.parseInt(buscarIDFazenda.getText()));
            		buscas.clear();
            		caprinos.clear(); 
               	 	caprinos.addAll(cDAO.relatorio()); 
               	 	tbvRelatorio.refresh();
        	       	alert.setTitle("");
        	 		alert.setHeaderText("");
            		alert.setContentText("Animais excluidos com sucesso!");
            		alert.show();
        		}else {
            		alert.setTitle("");
            		alert.setHeaderText("");
            		alert.setContentText("Exclusão cancelada!");
            		alert.show();
            	}
	    	} else {
	         	alertC.setTitle("");
	        	alertC.setHeaderText("");
	        	alertC.setContentText("Atenção, tem certeza que deseja remover esse animal?");
	        	opc = alertC.showAndWait();
	        	if(opc.get()==ButtonType.OK) {
				cDAO.excluir(Integer.parseInt(buscarID.getText()));
	    		buscas.clear();
	    		caprinos.clear(); //Limpar a  ObservableList
	       	 	caprinos.addAll(cDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Animal excluido com sucesso!");
	    		alert.show();
	        	}else {
	        		alert.setTitle("");
	        		alert.setHeaderText("");
	        		alert.setContentText("Exclusão cancelada!");
	        		alert.show();
	        	}
	    	} 
    }

    @FXML
    void onClickBtnVoltar(ActionEvent event) {
    	Main.changeScreen(1);
    }	

}



