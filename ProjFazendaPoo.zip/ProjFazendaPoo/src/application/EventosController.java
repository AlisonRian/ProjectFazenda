package application;


import java.util.Optional;

import dominio.Evento;
import dominio.Fazenda;
import dominio.FazendaEvento;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import persistencia.EventoDAO;
import persistencia.FazendaEventosDAO;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;


public class EventosController {
	 @FXML
	    private Button btnBuscar;

	    @FXML
	    private Button btnInserir;

	    @FXML
	    private Button btnRelatorio;

	    @FXML
	    private Button btnRemover;
	    
	    @FXML
	    private Button btnConfirmar;

	    @FXML
	    private Button btnVoltar;
	    
	    @FXML
	    private Button btnEditar;
	    
	    @FXML
	    private TextField buscarID;

	    @FXML
	    private DatePicker inserirData;

	    @FXML
	    private TextField inserirID;

	    @FXML
	    private TextField inserirLocal;

	    @FXML
	    private TextField inserirNome;
	    
	    @FXML
	    private DatePicker editarData;

	    @FXML
	    private TextField editarLocal;

	    @FXML
	    private TextField editarNome;
	    
	    @FXML
	    private Pane pnEditar;

	    @FXML
	    private TableColumn<Evento, String> tbcBscData;

	    @FXML
	    private TableColumn<Evento, String> tbcBscID;

	    @FXML
	    private TableColumn<Evento, String> tbcBscLocal;

	    @FXML
	    private TableColumn<Evento, String> tbcBscNome;

	    @FXML
	    private TableColumn<Evento, String> tbcData;

	    @FXML
	    private TableColumn<Evento, Integer> tbcID;

	    @FXML
	    private TableColumn<Evento, String> tbcLocal;

	    @FXML
	    private TableColumn<Evento, String> tbcNome;

	    @FXML
	    private TableView<Evento> tbvBuscar;

	    @FXML
	    private TableView<Evento> tbvRelatorio;
	    
	    private boolean rel = false;
	    Evento e;
	    EventoDAO eDAO = new EventoDAO();
	    FazendaEventosDAO fDAO = new FazendaEventosDAO();
	    private ObservableList<Evento> eventos = FXCollections.observableArrayList();
	    private ObservableList<Evento> buscas = FXCollections.observableArrayList();
	    Optional<ButtonType> opc;
	    Alert alert = new Alert(AlertType.INFORMATION);
	    Alert alertC = new Alert(AlertType.CONFIRMATION);
	    
	    public void initialize() {
	        pnEditar.setVisible(false);
	    }   
	    @FXML
	    void onClickBtnBuscar(ActionEvent event) {
	    	buscas.clear();
		    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
		    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
		    tbcBscLocal.setCellValueFactory(new PropertyValueFactory<>("local")); 
		    tbcBscData.setCellValueFactory(new PropertyValueFactory<>("data")); 
	    	buscas.add(eDAO.buscar(Integer.parseInt(buscarID.getText())));
	    	tbvBuscar.setItems(buscas);
	    }

	    @FXML
	    void onClickBtnInserir(ActionEvent event) {
	    	e = new Evento();
	    	e.setNome(inserirNome.getText());
	    	e.setLocal(inserirLocal.getText());
	    	e.setData(inserirData.getEditor().getText());
	    	e.setId(Integer.parseInt(inserirID.getText()));
	    	eDAO.inserir(e.getId(),e.getNome(),e.getData(),e.getLocal());
	    	
	    	 eventos.clear(); //Limpar a  ObservableList
	    	 eventos.addAll(eDAO.relatorio()); // Inserir os novos dados
	    	 tbvRelatorio.refresh();// Atualizar a TableView
	    	 alert.setTitle("");
	    	 alert.setHeaderText("");
	    	 alert.setContentText("Dados inseridos com sucesso!");
	    	 alert.show();
	    	 inserirID.setText("");
	    	 inserirNome.setText("");
	    	 inserirData.setValue(null);
	    	 inserirLocal.setText("");
	    }

	    @FXML
	    void onClickBtnRelatorio(ActionEvent event) {
	    	 if(rel==false) {
	    		    tbcID.setCellValueFactory(new PropertyValueFactory<>("id")); 
	    		    tbcNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
	    		    tbcLocal.setCellValueFactory(new PropertyValueFactory<>("local"));
	    		    tbcData.setCellValueFactory(new PropertyValueFactory<>("data"));
	    		   
	    		    eventos.addAll(eDAO.relatorio());
	    		    tbvRelatorio.setItems(eventos);
	    	 }
	    	 rel=true;
	    }

	    @FXML
	    void onClickBtnRemover(ActionEvent event) {
	    	alertC.setTitle("Remover");
	    	alertC.setHeaderText("");
	    	alertC.setContentText("Deseja remover esse evento?");
	    	opc = alertC.showAndWait();
	    	if(opc.get() == ButtonType.OK) {
	    		fDAO.excluirIdEventos(Integer.parseInt(buscarID.getText()));
	    		eDAO.excluir(Integer.parseInt(buscarID.getText()));
	    		buscas.clear();
	    		eventos.clear(); //Limpar a  ObservableList
	       	 	eventos.addAll(eDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	 	alert.setTitle("");
	    		alert.setHeaderText("");
	    		alert.setContentText("Evento excluido com sucesso!");
	    		alert.show();
	    		buscarID.setText("");
	    	} else {
	    		alert.setTitle("");
	    		alert.setHeaderText("");
	    		alert.setContentText("Exclusão cancelada!");
	    		alert.show();
	    	}
	    }
	    
	    @FXML
	    void onClickBtnVoltar(ActionEvent event) {
	    	Main.changeScreen(1);
	    }
	    
	    @FXML
	    void onClickBtnConfirmar(ActionEvent event) {
	    	alertC.setTitle("");
	    	alertC.setHeaderText("Alteração da Fazenda de ID "+buscarID.getText());
	    	alertC.setContentText("Tem certeza de que deseja editar essa fazenda?");
	    	opc = alertC.showAndWait();
	    	if(opc.get() == ButtonType.OK) {
	    		e = eDAO.buscar(Integer.parseInt(buscarID.getText()));
	    		eDAO.alterar(editarNome.getText(),editarData.getEditor().getText(),editarLocal.getText(),Integer.parseInt(buscarID.getText()));
	    		buscas.clear();
	    		eventos.clear(); //Limpar a  ObservableList
	       	 	eventos.addAll(eDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Alteração realizada com sucesso!");
	    		alert.show();
	    		buscarID.setText("");
	    	} else {
	    		alert.setTitle("");
	    		alert.setHeaderText("");
	    		alert.setContentText("Alteração cancelada!");
	    		alert.show();
	    	}
	    	pnEditar.setVisible(false);
	    }
	    
	    @FXML
	    void onClickBtnEditar(ActionEvent event) {
	    	pnEditar.setVisible(true);
	    }


}