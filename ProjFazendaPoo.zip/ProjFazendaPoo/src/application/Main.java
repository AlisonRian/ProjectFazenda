package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;


public class Main extends Application {
	
	private static Stage stage;
	
	private static Scene principalScene;
	private static Scene fazendaScene;
	private static Scene eventosScene;
	private static Scene caprinosScene;
	private static Scene fazendaEventosScene;
	private static Scene veterinariosScene;
	private static Scene fornecedoresScene;

	
	@Override
	public void start(Stage stagePrincipal) throws IOException {
		stage = stagePrincipal;
		stagePrincipal.setTitle("Inicio");
        
        
		Parent fxmlTela = FXMLLoader.load(getClass().getResource("FXMLTela.fxml"));
		principalScene = new Scene(fxmlTela);
		
        Parent fxmlFazenda = FXMLLoader.load(getClass().getResource("FXMLFazenda.fxml"));
        fazendaScene = new Scene(fxmlFazenda);
        
        Parent fxmlEventos = FXMLLoader.load(getClass().getResource("FXMLEventos.fxml"));
        eventosScene = new Scene(fxmlEventos);
        
        Parent fxmlCaprinos = FXMLLoader.load(getClass().getResource("FXMLCaprinos.fxml"));
        caprinosScene = new Scene(fxmlCaprinos);
        
        Parent fxmlFazendaEventos = FXMLLoader.load(getClass().getResource("FXMLFazendaEventos.fxml"));
        fazendaEventosScene = new Scene(fxmlFazendaEventos);
        
        Parent fxmlVeterinarios = FXMLLoader.load(getClass().getResource("FXMLVeterinarios.fxml"));
        veterinariosScene = new Scene(fxmlVeterinarios);
        
        Parent fxmlFornecedores = FXMLLoader.load(getClass().getResource("FXMLFornecedores.fxml"));
        fornecedoresScene = new Scene(fxmlFornecedores);
        
        
        stagePrincipal.setScene(principalScene);
        stagePrincipal.show();
	}
	
	public static void changeScreen(int screen) {
		switch(screen) {
		case 1:
			stage.setScene(principalScene);
			stage.setTitle("Inicio");
			break;
		case 2:
			stage.setScene(fazendaScene);
			stage.setTitle("Fazenda");
			break;
		case 3:
			stage.setScene(eventosScene);
			stage.setTitle("Eventos");
			break;
		case 4:
			stage.setScene(caprinosScene);
			stage.setTitle("Caprinos");
			break;
		case 5:
			stage.setScene(fazendaEventosScene);
			stage.setTitle("FazendaEventos");
			break;
		case 6:
			stage.setScene(veterinariosScene);
			stage.setTitle("Veterinarios");
			break;
		case 7:
			stage.setScene(fornecedoresScene);
			stage.setTitle("Fornecedores");
			break;
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
