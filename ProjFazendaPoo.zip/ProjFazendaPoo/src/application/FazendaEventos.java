package application;

public class FazendaEventos {
	private int id_fazenda, id_eventos;
	
	public FazendaEventos() {
		
	}
	public FazendaEventos(int id_fazenda, int id_eventos) {
		this.id_fazenda = id_fazenda;
		this.id_eventos = id_eventos;
	}
	
	public void setIdFazenda(int id_fazenda) {
		this.id_fazenda = id_fazenda;
	}
	
	public void setIdEventos(int id_eventos) {
		this.id_eventos = id_eventos;
	}
	
	public int getIdFazenda() {
		return id_fazenda;
	}
	
	public int getIdEventos() {
		return id_eventos;
	}
}
