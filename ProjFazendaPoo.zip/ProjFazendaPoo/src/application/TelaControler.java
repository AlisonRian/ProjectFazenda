package application;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

public class TelaControler implements Initializable{

    @FXML
    private Button btnCaprinos;

    @FXML
    private Button btnEventos;

    @FXML
    private Button btnFazenda;

    @FXML
    private Button btnFazendaEventos;

    @FXML
    private Button btnFornecedores;

    @FXML
    private Button btnVeterinarios;

    @FXML
    private AnchorPane painelPrincipal;

    @FXML
    void onClickBtnCaprinos(ActionEvent event) {
    	Main.changeScreen(4);
    }

    @FXML
    void onClickBtnEventos(ActionEvent event) {
    	Main.changeScreen(3);
    }

    @FXML
    void onClickBtnFazenda(ActionEvent event) {
    	Main.changeScreen(2);
    }

    @FXML
    void onClickBtnFazendaEventos(ActionEvent event) {
    	Main.changeScreen(5);
    }

    @FXML
    void onClickBtnFornecedores(ActionEvent event) {
    	Main.changeScreen(7);
    }

    @FXML
    void onClickBtnVeterinarios(ActionEvent event) {
    	Main.changeScreen(6);
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}




