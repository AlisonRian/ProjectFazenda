package application;

import java.util.Optional;

import dominio.Veterinario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import persistencia.VeterinarioDAO;

public class VeterinariosController {

    @FXML
    private Button btnBuscar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnRelatorio;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnVoltar;

    @FXML
    private TextField buscarID;

    @FXML
    private TextField buscarIDFazenda;

    @FXML
    private TextField editarNome;

    @FXML
    private TextField editarContato;

    @FXML
    private TextField inserirContato;

    @FXML
    private TextField inserirID;

    @FXML
    private TextField inserirIDFazenda;

    @FXML
    private TextField inserirNome;

    @FXML
    private Pane pnEditar;

    @FXML
    private TableColumn<Veterinario, String> tbcBscContato;

    @FXML
    private TableColumn<Veterinario, Integer> tbcBscID;

    @FXML
    private TableColumn<Veterinario, Integer> tbcBscIDFazenda;

    @FXML
    private TableColumn<Veterinario, String> tbcBscNome;

    @FXML
    private TableColumn<Veterinario, String> tbcContato;

    @FXML
    private TableColumn<Veterinario, Integer> tbcID;

    @FXML
    private TableColumn<Veterinario, Integer> tbcIdFazenda;

    @FXML
    private TableColumn<Veterinario, String> tbcNome;

    @FXML
    private TableView<Veterinario> tbvBuscar;

    @FXML
    private TableView<Veterinario> tbvRelatorio;
    
    private boolean rel=false;
    Veterinario v;
    VeterinarioDAO vDAO = new VeterinarioDAO();
    private ObservableList<Veterinario> veterinarios = FXCollections.observableArrayList();
    private ObservableList<Veterinario> buscas = FXCollections.observableArrayList();
    Optional<ButtonType> opc;
    Alert alert = new Alert(AlertType.INFORMATION);
    Alert alertC = new Alert(AlertType.CONFIRMATION);

    public void initialize() {
        pnEditar.setVisible(false);
    }   

    @FXML
    void onClickBtnBuscar(ActionEvent event) {
    	btnEditar.setDisable(false);
    	buscas.clear();
    	if(!buscarIDFazenda.getText().equals("")) {
    		btnEditar.setDisable(true);
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.addAll(vDAO.buscarIdFazenda(Integer.parseInt(buscarIDFazenda.getText())));
        	tbvBuscar.setItems(buscas);
    	} else if(!buscarID.getText().equals("")) {
    	    tbcBscID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
    	    tbcBscNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    	    tbcBscContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
    	    tbcBscIDFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
        	buscas.add(vDAO.buscar(Integer.parseInt(buscarID.getText())));
        	tbvBuscar.setItems(buscas);
    	}

    }

    @FXML
    void onClickBtnConfirmar(ActionEvent event) {
    	alertC.setTitle("");
    	alertC.setHeaderText("Alteração do veterinário de ID "+buscarID.getText());
    	alertC.setContentText("Tem certeza de que deseja editar esse registro?");
    	opc = alertC.showAndWait();
    	if(opc.get() == ButtonType.OK) {
    		v = vDAO.buscar(Integer.parseInt(buscarID.getText()));
    		vDAO.alterar(editarNome.getText(),editarContato.getText(),Integer.parseInt(buscarID.getText()));
    		buscas.clear();
    		veterinarios.clear(); //Limpar a  ObservableList
       	 	veterinarios.addAll(vDAO.relatorio()); // Inserir os novos dados
       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	alert.setTitle("");
	 		alert.setHeaderText("");
    		alert.setContentText("Alteração realizada com sucesso!");
    		alert.show();
    	} else {
    		alert.setTitle("");
    		alert.setHeaderText("");
    		alert.setContentText("Alteração cancelada!");
    		alert.show();
    	}
    	pnEditar.setVisible(false);
    }

    @FXML
    void onClickBtnEditar(ActionEvent event) {
    	pnEditar.setVisible(true);
    }

    @FXML
    void onClickBtnInserir(ActionEvent event) {
    	v = new Veterinario();
    	v.setId(Integer.parseInt(inserirID.getText()));
    	v.setIdFazenda(Integer.parseInt(inserirIDFazenda.getText()));
    	v.setNome(inserirNome.getText());
    	v.setContato(inserirContato.getText());
    	vDAO.inserir(v.getId(),v.getIdFazenda(),v.getNome(),v.getContato());
    	
    	 veterinarios.clear(); //Limpar a  ObservableList
    	 veterinarios.addAll(vDAO.relatorio()); // Inserir os novos dados
    	 tbvRelatorio.refresh();// Atualizar a TableView
    	 alert.setTitle("");
    	 alert.setHeaderText("");
    	 alert.setContentText("Dados inseridos com sucesso!");
    	 alert.show();
    	 inserirID.setText("");
    	 inserirNome.setText("");
    	 inserirContato.setText("");
    	 inserirIDFazenda.setText("");
    }

    @FXML
    void onClickBtnRelatorio(ActionEvent event) {
    	if(rel==false) {
  		  	tbcID.setCellValueFactory(new PropertyValueFactory<>("id")); 
  		    tbcNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
  		    tbcContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
  		    tbcIdFazenda.setCellValueFactory(new PropertyValueFactory<>("idFazenda")); 
  		    veterinarios.addAll(vDAO.relatorio());
  		    tbvRelatorio.setItems(veterinarios);
  		    rel=true;
    	}
    	veterinarios.clear(); 
   	 	veterinarios.addAll(vDAO.relatorio()); 
   	 	tbvRelatorio.refresh();
    }

    @FXML
    void onClickBtnRemover(ActionEvent event) {
    	if(!buscarIDFazenda.getText().equals("")){
    		alertC.setTitle("");
        	alertC.setHeaderText("");
        	alertC.setContentText("Atenção, excluir utilizando o ID da fazenda irá excluir todos relacionados a fazenda!");
        	opc = alertC.showAndWait();
        	if(opc.get() == ButtonType.OK) {
            		vDAO.excluirIdFazenda(Integer.parseInt(buscarIDFazenda.getText()));
            		buscas.clear();
            		veterinarios.clear(); //Limpar a  ObservableList
               	 	veterinarios.addAll(vDAO.relatorio()); // Inserir os novos dados
               	 	tbvRelatorio.refresh();// Atualizar a TableView
        	       	alert.setTitle("");
        	 		alert.setHeaderText("");
            		alert.setContentText("Veterinários excluidos com sucesso!");
            		alert.show();
        		}else {
            		alert.setTitle("");
            		alert.setHeaderText("");
            		alert.setContentText("Exclusão cancelada!");
            		alert.show();
            	}
	    	} else {
	         	alertC.setTitle("");
	        	alertC.setHeaderText("");
	        	alertC.setContentText("Atenção, tem certeza que deseja remover esse Veterinário");
	        	opc = alertC.showAndWait();
	        	if(opc.get()==ButtonType.OK) {
				vDAO.excluir(Integer.parseInt(buscarID.getText()));
	    		buscas.clear();
	    		veterinarios.clear(); //Limpar a  ObservableList
	       	 	veterinarios.addAll(vDAO.relatorio()); // Inserir os novos dados
	       	 	tbvRelatorio.refresh();// Atualizar a TableView
		       	alert.setTitle("");
		 		alert.setHeaderText("");
	    		alert.setContentText("Veterinário excluido com sucesso!");
	    		alert.show();
	        	}else {
	        		alert.setTitle("");
	        		alert.setHeaderText("");
	        		alert.setContentText("Exclusão cancelada!");
	        		alert.show();
	        	}
	    	} 
    }

    @FXML
    void onClickBtnVoltar(ActionEvent event) {
    	Main.changeScreen(1);
    }	

}

