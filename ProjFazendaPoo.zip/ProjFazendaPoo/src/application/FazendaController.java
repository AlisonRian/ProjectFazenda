package application;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import dominio.Fazenda;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import persistencia.CaprinoDAO;
import persistencia.FazendaDAO;
import persistencia.FazendaEventosDAO;
import persistencia.FornecedorDAO;
import persistencia.VeterinarioDAO;

public class FazendaController {
    @FXML
    private Button btnBuscar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnRelátorio;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnVoltar;
    
    @FXML
    private Button btnEditar;
    
    @FXML
    private Button btnConfirmar;
    
    @FXML
    private TextField buscarID;

    @FXML
    private TextField inserirID;

    @FXML
    private TextField inserirNome;

    @FXML
    private TextField inserirQtd;
    
    @FXML
    private TextField editarNome;

    @FXML
    private TextField editarQtd;

    @FXML
    private Label lblEditarNome;

    @FXML
    private Label lblEditarQtd;
    
    @FXML
    private Pane pnEditar;

    @FXML
    private TableColumn<Fazenda, Integer> tbcBuscarID;

    @FXML
    private TableColumn<Fazenda, String> tbcBuscarNome;

    @FXML
    private TableColumn<Fazenda, Integer> tbcBuscarQtd;
    
    @FXML
    private TableColumn<Fazenda, Integer> tbcId;

    @FXML
    private TableColumn<Fazenda, String> tbcNome;

    @FXML
    private TableColumn<Fazenda, Integer> tbcQtd;
    
    @FXML
    private TableView<Fazenda> tbvRelatorio;
    
    @FXML
    private TableView<Fazenda> tbvBuscar;

    @FXML
    private AnchorPane telaFazenda;

    private boolean rel=false;
    
    CaprinoDAO cDAO = new CaprinoDAO();
    VeterinarioDAO vDAO = new VeterinarioDAO();
    FornecedorDAO forDAO = new FornecedorDAO();
    FazendaEventosDAO feDAO = new FazendaEventosDAO();
    Fazenda f;
    FazendaDAO fDAO = new FazendaDAO();
    private ObservableList<Fazenda> fazendas = FXCollections.observableArrayList();
    private ObservableList<Fazenda> buscas = FXCollections.observableArrayList();
    Optional<ButtonType> opc;
    Alert alert = new Alert(AlertType.INFORMATION);
    Alert alertC = new Alert(AlertType.CONFIRMATION);
    
    public void initialize() {
        pnEditar.setVisible(false);
    }    
    
    
    @FXML
    void onClickBtnBuscar(ActionEvent event) {
    	buscas.clear();
	    tbcBuscarID.setCellValueFactory(new PropertyValueFactory<>("id")); //nome do atributo
	    tbcBuscarNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
	    tbcBuscarQtd.setCellValueFactory(new PropertyValueFactory<>("Qtd")); 
    	buscas.add(fDAO.buscar(Integer.parseInt(buscarID.getText())));
    	tbvBuscar.setItems(buscas);
    }

    @FXML
    void onClickBtnInserir(ActionEvent event) {
    	f = new Fazenda();
    	f.setId(Integer.parseInt(inserirID.getText()));
    	f.setNome(inserirNome.getText());
    	f.setQtd(Integer.parseInt(inserirQtd.getText()));
    	fDAO.inserir(f.getId(),f.getNome(),f.getQtd());
    	
    	 fazendas.clear(); //Limpar a  ObservableList
    	 fazendas.addAll(fDAO.relatorio()); // Inserir os novos dados
    	 tbvRelatorio.refresh();// Atualizar a TableView
    	 alert.setTitle("");
    	 alert.setHeaderText("");
    	 alert.setContentText("Dados inseridos com sucesso!");
    	 alert.show();
    	 inserirID.setText("");
    	 inserirNome.setText("");
    	 inserirQtd.setText("");
    }

    @FXML
    void onClickBtnRelatorio(ActionEvent event) {
    	if(rel==false) {
    		  tbcId.setCellValueFactory(new PropertyValueFactory<>("id")); 
    		    tbcNome.setCellValueFactory(new PropertyValueFactory<>("nome")); 
    		    tbcQtd.setCellValueFactory(new PropertyValueFactory<>("Qtd")); 
    		    fazendas.addAll(fDAO.relatorio());
    		    tbvRelatorio.setItems(fazendas);
    		    rel=true;
    	}
	    
    }

    @FXML
    void onClickBtnRemover(ActionEvent event) {
    	alertC.setTitle("");
    	alertC.setHeaderText("Atenção, excluir essa fazenda irá excluir todos os registros relacionados a ela!");
    	alertC.setContentText("Tem certeza de que deseja excluir essa fazenda?");
    	opc = alertC.showAndWait();
    	if(opc.get() == ButtonType.OK) {
    		cDAO.excluirIdFazenda(Integer.parseInt(buscarID.getText()));
    		forDAO.excluirIdFazenda(Integer.parseInt(buscarID.getText()));
    		vDAO.excluirIdFazenda(Integer.parseInt(buscarID.getText()));
    		feDAO.excluirIdFazenda(Integer.parseInt(buscarID.getText()));
    		fDAO.excluir(Integer.parseInt(buscarID.getText()));
    		buscas.clear();
    		fazendas.clear(); //Limpar a  ObservableList
       	 	fazendas.addAll(fDAO.relatorio()); // Inserir os novos dados
       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	alert.setTitle("");
	 		alert.setHeaderText("");
    		alert.setContentText("Fazenda excluida com sucesso!");
    		alert.show();
    	} else {
    		alert.setTitle("");
    		alert.setHeaderText("");
    		alert.setContentText("Exclusão cancelada!");
    		alert.show();
    	}
    }

    @FXML
    void onClickBtnVoltar(ActionEvent event) {
    	Main.changeScreen(1);
    }
    

    @FXML
    void onClickBtnEditar(ActionEvent event) {
    	pnEditar.setVisible(true);
    }
    
    @FXML
    void onClickBtnConfirmar(ActionEvent event) {
    	alertC.setTitle("");
    	alertC.setHeaderText("Alteração da Fazenda de ID "+buscarID.getText());
    	alertC.setContentText("Tem certeza de que deseja editar essa fazenda?");
    	opc = alertC.showAndWait();
    	if(opc.get() == ButtonType.OK) {
    		f = fDAO.buscar(Integer.parseInt(buscarID.getText()));
    		fDAO.alterar(editarNome.getText(), Integer.parseInt(editarQtd.getText()),Integer.parseInt(buscarID.getText()));
    		buscas.clear();
    		fazendas.clear(); //Limpar a  ObservableList
       	 	fazendas.addAll(fDAO.relatorio()); // Inserir os novos dados
       	 	tbvRelatorio.refresh();// Atualizar a TableView
	       	alert.setTitle("");
	 		alert.setHeaderText("");
    		alert.setContentText("Alteração realizada com sucesso!");
    		alert.show();
    	} else {
    		alert.setTitle("");
    		alert.setHeaderText("");
    		alert.setContentText("Alteração cancelada!");
    		alert.show();
    	}
    	pnEditar.setVisible(false);
    }
    

}
